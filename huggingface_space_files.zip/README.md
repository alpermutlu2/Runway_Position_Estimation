# 🛬 Runway Position Estimation (Hugging Face Space)

This Streamlit app performs visual localization for runway videos using a hybrid pipeline that combines:

- Semantic Segmentation (SAM)
- RANSAC-based line fitting
- LightGlue/ORB-SLAM3-based tracking
- M4Depth and RAFT fusion for depth & flow
- Pose estimation and trajectory visualization

## 🚀 Try it out:
1. Upload a video with visible runway segments.
2. Run the hybrid localization pipeline.
3. See the predicted path visualized on the output.

---

⚠️ Best run with GPU acceleration. Supports CPU with slower processing.