import streamlit as st
import tempfile
import os
import cv2
from main import main as pipeline_main
import argparse

st.set_page_config(page_title='Runway Position Estimation', layout='centered')

st.title("🛬 Runway Position Estimation")
st.write("Upload a video below to estimate the runway-relative pose using a hybrid visual pipeline.")

uploaded_video = st.file_uploader("Upload a runway video", type=["mp4", "avi", "mov"])

if uploaded_video:
    with tempfile.NamedTemporaryFile(delete=False, suffix='.mp4') as temp_file:
        temp_file.write(uploaded_video.read())
        video_path = temp_file.name

    st.video(video_path)
    
    if st.button("Run Estimation"):
        with st.spinner("Processing..."):
            os.system(f"python main.py --video {video_path} --save")
        st.success("✅ Inference completed.")
        st.video("output.avi")